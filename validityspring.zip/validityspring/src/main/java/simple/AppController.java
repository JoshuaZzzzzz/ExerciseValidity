package simple;

import com.opencsv.CSVReader;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

@Controller
public class AppController {

    @RequestMapping("/")
    public String index(Model model) {

        String csvFile = "src/main/resources/advanced.csv";

        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;

            HashMap<String, CustomerInfo> map = new HashMap<String, CustomerInfo>();

            HashMap<String, String> dupMap = new HashMap<String, String>();

            ArrayList<CustomerInfo> list = new ArrayList<>();
            int i=0;
            while ((line = reader.readNext()) != null) {
                CustomerInfo customerInfo = new CustomerInfo();

                if(line[1].equals("first_name"))
                {
                    continue;
                }else{
                    customerInfo.id = i;
                    customerInfo.first_name = line[1];
                    customerInfo.last_name = line[2];
                    customerInfo.company = line[3];
                    customerInfo.email = line[4];
                    customerInfo.address1 = line[5];
                    customerInfo.address2 = line[6];
                    customerInfo.zip = line[7];
                    customerInfo.city = line[8];
                    customerInfo.state_long = line[9];
                    customerInfo.state = line[10];
                    customerInfo.phone = line[11];


                    if(map.containsKey(line[4]))
                    {
                        dupMap.put(line[11],line[4]);
                        list.add(customerInfo);
                        map.remove(line[4]);
                    }else {


                        map.put(line[4], customerInfo);
                    }
                    i++;

                }
            }

            ArrayList<CustomerInfo> listAfterOneFilter = new ArrayList<>(map.values());
            ArrayList<CustomerInfo> listAfterTwoFilter = new ArrayList<>();

            for(CustomerInfo customer: listAfterOneFilter){
                if(dupMap.containsKey(customer.phone))
                    continue;
                else
                    listAfterTwoFilter.add(customer);
            }

            model.addAttribute("filteredList",listAfterTwoFilter);
            model.addAttribute("list",list);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return "index";

    }

}